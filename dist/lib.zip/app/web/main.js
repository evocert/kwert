//demo main
define([
	"module",
	"../../lib/demo/web/index"
],function(
	module,
	demolib
){
	"use strict";
	function App(){
		console.log("App:start");
		console.log("App:end");
	}
	module.exports=App;
});
